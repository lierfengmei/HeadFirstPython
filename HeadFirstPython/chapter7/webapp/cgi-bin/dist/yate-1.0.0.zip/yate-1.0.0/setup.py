from  distutils.core import setup

setup(
    name= 'athletemodel',
    version='1.0.0',
    py_modules = 'athletemodel',
    description='This is the athlete model',
)

setup(
    name='yate',
    version='1.0.0',
    py_modules = 'yate.py',
    description='the yate model is used for create html',
)